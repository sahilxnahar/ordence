import { cn } from "@/lib/utils";

/**
 * Official Ordence "Orbital" brand assets, inlined from the brand kit
 * (`ordence-brand-kit/masters/`).
 *
 * Why inline instead of <img src="/brand/...svg">:
 *  - zero extra requests, crisp at any DPR
 *  - the kit's Ink Navy (#111827) fills are swapped to `currentColor`,
 *    so the mark and wordmark re-ink themselves in dark mode and on
 *    navy panels automatically — violet and coral stay fixed, exactly
 *    as the reversed/on-navy kit masters specify.
 *
 * The raw kit masters also ship in `public/brand/` for emails, CMS
 * content and anywhere inline SVG isn't possible.
 */

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 600 600"
      aria-hidden="true"
      className={cn("size-14", className)}
    >
      <g transform="translate(167.00 292.00) rotate(-6.00)">
        <path
          d="M89 724Q89 948 156 1100Q206 1212 292.5 1301.0Q379 1390 482 1433Q619 1491 798 1491Q1122 1491 1316.5 1290.0Q1511 1089 1511 731Q1511 376 1318.0 175.5Q1125 -25 802 -25Q475 -25 282.0 174.5Q89 374 89 724ZM394 734Q394 485 509.0 356.5Q624 228 801 228Q978 228 1091.5 355.5Q1205 483 1205 738Q1205 990 1094.5 1114.0Q984 1238 801 1238Q618 1238 506.0 1112.5Q394 987 394 734Z"
          fill="currentColor"
          transform="translate(-55.4688 50.8232) scale(0.069336 -0.069336)"
        />
      </g>
      <g transform="translate(222.00 192.00) rotate(-18.00)">
        <path
          d="M241 389H333Q361 389 384.0 396.0Q407 403 423.5 420.5Q440 438 449.0 468.0Q458 498 458 544Q458 596 444.5 627.5Q431 659 409.5 675.0Q388 691 361.5 696.0Q335 701 309 701Q291 701 272.5 700.5Q254 700 241 698ZM30 14H141V698H30V712H220Q232 712 244.0 712.5Q256 713 268 714Q280 714 292.0 714.5Q304 715 316 715Q375 715 420.0 708.5Q465 702 504 671Q539 644 553.5 610.0Q568 576 568 546Q568 531 562.5 507.5Q557 484 538.5 459.5Q520 435 485.0 414.5Q450 394 392 387V385Q408 383 435.5 377.5Q463 372 491.5 359.0Q520 346 544.0 324.5Q568 303 578 269Q584 249 586.5 223.5Q589 198 590.5 171.0Q592 144 593.5 119.0Q595 94 599 77Q605 51 618.0 30.0Q631 9 660 9Q673 9 687.0 14.0Q701 19 712 30L721 19Q716 15 709.5 10.5Q703 6 693.0 2.0Q683 -2 668.5 -4.5Q654 -7 633 -7Q593 -7 566.5 3.0Q540 13 524.0 32.5Q508 52 500.5 80.5Q493 109 490 147L483 238Q479 288 463.0 316.0Q447 344 425.5 357.0Q404 370 381.0 372.5Q358 375 341 375H241V14H352V0H30Z"
          fill="#FF5C5C"
          transform="translate(-48.0640 45.3120) scale(0.128000 -0.128000)"
        />
      </g>
      <g transform="translate(307.00 151.00) rotate(0.00)">
        <path
          d="M241 14Q258 12 280.5 11.0Q303 10 330 10Q364 10 397.5 13.5Q431 17 461.5 28.5Q492 40 518.5 61.5Q545 83 566 118Q598 172 610.5 228.5Q623 285 623 352Q623 431 608.0 495.5Q593 560 558.5 605.5Q524 651 467.0 676.0Q410 701 326 701Q301 701 280.5 700.0Q260 699 241 698ZM30 14H141V698H30V712H216Q230 712 244.0 712.5Q258 713 272 714Q286 714 300.0 714.5Q314 715 328 715Q358 715 381.5 714.0Q405 713 425.5 710.5Q446 708 464.5 703.5Q483 699 504 692Q565 672 609.5 638.5Q654 605 682.5 561.0Q711 517 724.5 465.0Q738 413 738 356Q738 290 722.0 237.5Q706 185 678.0 144.5Q650 104 612.5 74.5Q575 45 532 27Q508 16 486.5 10.0Q465 4 442.5 1.0Q420 -2 393.0 -3.0Q366 -4 331 -4Q316 -4 299.0 -3.5Q282 -3 265.0 -2.0Q248 -1 231.5 -0.5Q215 0 200 0H30Z"
          fill="#6D45E8"
          transform="translate(-55.6800 51.5475) scale(0.145000 -0.145000)"
        />
      </g>
      <g transform="translate(403.00 205.00) rotate(37.00)">
        <path
          d="M149 0V1466H1236V1218H445V893H1181V646H445V247H1264V0Z"
          fill="currentColor"
          transform="translate(-38.6367 40.0859) scale(0.054688 -0.054688)"
        />
      </g>
      <g transform="translate(430.00 319.00) rotate(12.00)">
        <path
          d="M1087 539 1374 448Q1308 208 1154.5 91.5Q1001 -25 765 -25Q473 -25 285.0 174.5Q97 374 97 720Q97 1086 286.0 1288.5Q475 1491 783 1491Q1052 1491 1220 1332Q1320 1238 1370 1062L1077 992Q1051 1106 968.5 1172.0Q886 1238 768 1238Q605 1238 503.5 1121.0Q402 1004 402 742Q402 464 502.0 346.0Q602 228 762 228Q880 228 965.0 303.0Q1050 378 1087 539Z"
          fill="currentColor"
          transform="translate(-48.8418 48.6758) scale(0.066406 -0.066406)"
        />
      </g>
      <g transform="translate(320.00 424.00) rotate(-3.00)">
        <path
          d="M21 14H132V698H21V712H235L573 167H575V698H464V712H701V698H590V-14H570L149 657H147V14H258V0H21Z"
          fill="#6D45E8"
          transform="translate(-52.3450 50.6050) scale(0.145000 -0.145000)"
        />
      </g>
      <g transform="translate(210.00 397.00) rotate(-43.00)">
        <path
          d="M149 0V1466H1236V1218H445V893H1181V646H445V247H1264V0Z"
          fill="currentColor"
          transform="translate(-35.8770 37.2227) scale(0.050781 -0.050781)"
        />
      </g>
      <path
        d="M300 235 C315 255 335 255 344 275 C365 278 365 302 344 311 C336 335 313 335 300 354 C287 335 264 335 256 311 C235 302 235 278 256 275 C265 255 285 255 300 235"
        fill="none"
        stroke="#FF5C5C"
        strokeWidth="5.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="300" cy="235" r="4" fill="#FF5C5C" />
    </svg>
  );
}

export function LogoWordmark({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 1153.09 330"
      aria-hidden="true"
      className={cn("h-6 w-auto", className)}
    >
      <path
        d="M89 724Q89 948 156 1100Q206 1212 292.5 1301.0Q379 1390 482 1433Q619 1491 798 1491Q1122 1491 1316.5 1290.0Q1511 1089 1511 731Q1511 376 1318.0 175.5Q1125 -25 802 -25Q475 -25 282.0 174.5Q89 374 89 724ZM394 734Q394 485 509.0 356.5Q624 228 801 228Q978 228 1091.5 355.5Q1205 483 1205 738Q1205 990 1094.5 1114.0Q984 1238 801 1238Q618 1238 506.0 1112.5Q394 987 394 734Z"
        fill="currentColor"
        transform="translate(45.000 250.000) scale(0.090332 -0.090332)"
      />
      <path
        d="M150 0V1466H773Q1008 1466 1114.5 1426.5Q1221 1387 1285.0 1286.0Q1349 1185 1349 1055Q1349 890 1252.0 782.5Q1155 675 962 647Q1058 591 1120.5 524.0Q1183 457 1289 286L1468 0H1114L900 319Q786 490 744.0 534.5Q702 579 655.0 595.5Q608 612 506 612H446V0ZM446 846H665Q878 846 931.0 864.0Q984 882 1014.0 926.0Q1044 970 1044 1036Q1044 1110 1004.5 1155.5Q965 1201 893 1213Q857 1218 677 1218H446Z"
        fill="currentColor"
        transform="translate(211.899 250.000) scale(0.090332 -0.090332)"
      />
      <path
        d="M148 1466H689Q872 1466 968 1438Q1097 1400 1189.0 1303.0Q1281 1206 1329.0 1065.5Q1377 925 1377 719Q1377 538 1332 407Q1277 247 1175 148Q1098 73 967 31Q869 0 705 0H148ZM444 1218V247H665Q789 247 844 261Q916 279 963.5 322.0Q1011 365 1041.0 463.5Q1071 562 1071 732Q1071 902 1041.0 993.0Q1011 1084 957.0 1135.0Q903 1186 820 1204Q758 1218 577 1218Z"
        fill="currentColor"
        transform="translate(368.500 250.000) scale(0.090332 -0.090332)"
      />
      <path
        d="M149 0V1466H1236V1218H445V893H1181V646H445V247H1264V0Z"
        fill="currentColor"
        transform="translate(525.101 250.000) scale(0.090332 -0.090332)"
      />
      <path
        d="M152 0V1466H440L1040 487V1466H1315V0H1018L427 956V0Z"
        fill="currentColor"
        transform="translate(671.495 250.000) scale(0.090332 -0.090332)"
      />
      <path
        d="M1087 539 1374 448Q1308 208 1154.5 91.5Q1001 -25 765 -25Q473 -25 285.0 174.5Q97 374 97 720Q97 1086 286.0 1288.5Q475 1491 783 1491Q1052 1491 1220 1332Q1320 1238 1370 1062L1077 992Q1051 1106 968.5 1172.0Q886 1238 768 1238Q605 1238 503.5 1121.0Q402 1004 402 742Q402 464 502.0 346.0Q602 228 762 228Q880 228 965.0 303.0Q1050 378 1087 539Z"
        fill="currentColor"
        transform="translate(828.096 250.000) scale(0.090332 -0.090332)"
      />
      <path
        d="M149 0V1466H1236V1218H445V893H1181V646H445V247H1264V0Z"
        fill="currentColor"
        transform="translate(984.697 250.000) scale(0.090332 -0.090332)"
      />
    </svg>
  );
}

/** Primary lockup: orbital mark + wordmark. */
export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark />
      <LogoWordmark />
      <span className="sr-only">Ordence</span>
    </span>
  );
}
